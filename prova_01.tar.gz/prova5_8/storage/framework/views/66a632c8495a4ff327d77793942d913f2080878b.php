<?php $__env->startSection('content'); ?>
<html>
    <body>
        <h3>Editar Talento</h3>
        <div>
            <form action="/talentos/<?php echo e($talento->id); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <p>
                    <label for="nome">Nome:</label>
                    <input type="text" name="nome" value="<?php echo e($talento->nome); ?>">
                </p>
                <p>
                    <label for="matricula">Matrícula:</label>
                    <input type="text" name="matricula" value="<?php echo e($talento->matricula); ?>">
                </p>
                <p>
                    <label for="instituto">Instituto</label>
                    <input type="text" name="instituto" value="<?php echo e($talento->instituto); ?>">
                </p>
                <p>
                    <label for="funcao">Função</label>
                    <input type="text" name="funcao" value="<?php echo e($talento->funcao); ?>">
                </p>
                <p>
                    <label for="atividade">Atividade que executa</label>
                    <input type="text" name="atividade" value="<?php echo e($talento->atividade); ?>">
                </p>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </form>
        </div>
    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laravel/Área de trabalho/prova5_8/resources/views/talentos/edit.blade.php ENDPATH**/ ?>