<?php $__env->startSection('content'); ?>

<html>
    <body>
        <h2>Detalhes do Talento <?php echo e($talento->nome); ?></h2>
        
        <p>
            <form action="/talentos">
                <button type="submit" class="btn btn-primary">Listar Todos os Talentos</button>
            </form>
        </p>
        <p>
            <form action="/talentos/<?php echo e($talento->id); ?>/edit">
                <button type="submit" class="btn btn-primary">Editar</button>
            </form>
        </p>
        <p>
            <form action="/talentos/<?php echo e($talento->id); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>    
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">Deletar</button>
            </form>
        </p>
        <div>
            <p><strong>Código: </strong><?php echo e($talento->id); ?></p>
            <p><strong>Nome: </strong><?php echo e($talento->nome); ?></p>
            <p><strong>Matrícula: </strong><?php echo e($talento->matricula); ?></p>
            <p><strong>Instituto: </strong><?php echo e($talento->instituto); ?></p>
            <p><strong>Função: </strong><?php echo e($talento->funcao); ?></p>
            <p><strong>Ativdade: </strong><?php echo e($talento->atividade); ?></p>
        </div>
    </body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laravel/Área de trabalho/prova5_8/resources/views/talentos/show.blade.php ENDPATH**/ ?>