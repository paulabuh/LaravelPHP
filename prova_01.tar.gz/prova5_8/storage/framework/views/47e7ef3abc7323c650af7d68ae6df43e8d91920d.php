<?php $__env->startSection('content'); ?>
<html>
    <body>
        <h3>Lista de Talentos</h3>
        
        <p>
            <form action="/talentos/create">
                <button type="submit" class="btn btn-primary">Adicionar Talento</button>
            </form>
        </p>
        
        <br>
        Quantidade de registros: <?php echo e(count($talentos)); ?>

        <table class="table">
            <tr>
                <td>Editar</td>    
                <td>Visualizar</td>
                <td>Código</td>
                <td>Nome</td>
                <td>Matrícula</td>
                <td>Instituto</td>
                <td>Função</td>
                <td>Atividade</td>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $talentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><a href="/talentos/<?php echo e($talento->id); ?>/edit">Editar</a></td>
                <td><a href="/talentos/<?php echo e($talento->id); ?>">Ver</a></td>
                <td><?php echo e($talento->id); ?></td>
                <td><?php echo e($talento->nome); ?></td>
                <td><?php echo e($talento->matricula); ?></td>
                <td><?php echo e($talento->instituto); ?></td>
                <td><?php echo e($talento->funcao); ?></td>
                <td><?php echo e($talento->atividade); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            Não há talentos.
            <?php endif; ?>
        </table>
        <?php echo e($talentos->links()); ?>

    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laravel/Área de trabalho/prova5_8/resources/views/talentos/index.blade.php ENDPATH**/ ?>