<?php $__env->startSection('content'); ?>
<html>
    <body>
        <h3>Cadastro de Talento</h3>
        <div>
            <form action="/talentos" enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($error!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($error); ?>

                    </div>
                <?php endif; ?>
                <p>
                    <label for="nome">Nome:</label>
                    <input type="text" name="nome" value="<?php echo e(old('nome')); ?>">
                    <?php if($errors->first('nome')!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($errors->first('nome')); ?>

                    </div>
                    <?php endif; ?>
                </p>
                <p>
                    <label for="matricula">Matricula:</label>
                    <input type="text" name="matricula" value="<?php echo e(old('matricula')); ?>">
                    <?php if($errors->first('matricula')!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($errors->first('matricula')); ?>

                    </div>
                    <?php endif; ?>
                </p>
                <p>
                    <label for="instituto">Instituto:</label>
                    <input type="text" name="instituto" value="<?php echo e(old('instituto')); ?>">
                    <?php if($errors->first('instituto')!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($errors->first('instituto')); ?>

                    </div>
                    <?php endif; ?>
                </p>
                <p>
                    <label for="funcao">Função:</label>
                    <input type="text" name="funcao" value="<?php echo e(old('funcao')); ?>">
                    <?php if($errors->first('funcao')!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($errors->first('funcao')); ?>

                    </div>
                    <?php endif; ?>
                </p>
                <p>
                    <label for="atividade">Atividade que executa:</label>
                    <input type="text" name="atividade" value="<?php echo e(old('atividade')); ?>">
                    <?php if($errors->first('atividade')!=''): ?>
                    <div class="alert alert-danger">
                    <?php echo e($errors->first('atividade')); ?>

                    </div>
                    <?php endif; ?>
                </p>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </form>
        </div>
    </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/laravel/Área de trabalho/prova5_8/resources/views/talentos/create.blade.php ENDPATH**/ ?>