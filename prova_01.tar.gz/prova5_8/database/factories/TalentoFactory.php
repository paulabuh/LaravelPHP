<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use BancoTalentos\Models\Talento;
use Faker\Generator as Faker;

$factory->define(Talento::class, function (Faker $faker) {
    return [
        'nome' => $faker->Name,
        'matricula' => $faker->unique()->numberBetween(1234,2000),
        'instituto' => 'Instituto ' . $faker->unique()->numberBetween(1,20),
        'funcao' => $faker->jobTitle(),
        'atividade' => $faker->jobTitle()
    ];
});
