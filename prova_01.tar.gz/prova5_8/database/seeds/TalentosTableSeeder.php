<?php

use Illuminate\Database\Seeder;
use BancoTalentos\Models\Talento;

class TalentosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(BancoTalentos\Models\Talento::class, 20)->create()->make();
    }
}
